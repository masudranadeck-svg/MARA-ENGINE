package com.personal.aihub

import android.annotation.SuppressLint
import android.app.Activity
import android.content.ContentValues
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.text.InputType
import android.util.Base64
import android.view.Gravity
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import java.net.URL
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class MainActivity : Activity() {
    private lateinit var promptBox: EditText
    private lateinit var maxBox: EditText
    private lateinit var parBox: EditText
    private lateinit var logView: TextView
    private lateinit var scroll: ScrollView
    private lateinit var holder: FrameLayout
    private val ui = Handler(Looper.getMainLooper())
    private val pending = ArrayDeque<String>()
    private val active = HashSet<Worker>()
    private var running = false
    private var prompt = ""
    private var maxImgs = 12
    private var parallel = 3
    private var total = 0
    private var finished = 0
    private var root: File? = null
    private val report = StringBuilder()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 64, 32, 32) }
        promptBox = EditText(this).apply { hint = "আপনার প্রম্পট লিখুন"; minLines = 3; gravity = Gravity.TOP }
        maxBox = EditText(this).apply { setText("12"); hint = "ছবি প্রতি টুলে (0 = যত পারে)"; inputType = InputType.TYPE_CLASS_NUMBER }
        parBox = EditText(this).apply { setText("3"); hint = "একসাথে কয়টা টুল (১-৮)"; inputType = InputType.TYPE_CLASS_NUMBER }
        val startBtn = Button(this).apply { text = "শুরু (৩৩৩ টুল)"; setOnClickListener { start() } }
        val stopBtn = Button(this).apply { text = "থামাও"; setOnClickListener { stop() } }
        val zipBtn = Button(this).apply { text = "এখনই ZIP বানাও"; setOnClickListener { makeZip() } }
        logView = TextView(this).apply { textSize = 12f }
        scroll = ScrollView(this).apply { addView(logView) }
        holder = FrameLayout(this)
        col.addView(promptBox); col.addView(maxBox); col.addView(parBox)
        col.addView(startBtn); col.addView(stopBtn); col.addView(zipBtn)
        col.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        col.addView(holder, LinearLayout.LayoutParams(2, 2))
        setContentView(col)
    }

    private fun log(s: String) {
        logView.append(s + "\n")
        scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    private fun start() {
        if (running) return
        prompt = promptBox.text.toString().trim()
        if (prompt.isEmpty()) { Toast.makeText(this, "প্রম্পট দিন", Toast.LENGTH_SHORT).show(); return }
        maxImgs = maxBox.text.toString().toIntOrNull() ?: 12
        parallel = (parBox.text.toString().toIntOrNull() ?: 3).coerceIn(1, 8)
        root = File(getExternalFilesDir(null), "run_" + System.currentTimeMillis()).apply { mkdirs() }
        val slugs = assets.open("generators.txt").bufferedReader().readLines().map { it.trim() }.filter { it.isNotEmpty() }
        pending.clear(); pending.addAll(slugs)
        total = slugs.size; finished = 0; report.setLength(0)
        running = true
        log("শুরু: $total টা টুল, একসাথে $parallel টা")
        pump()
    }

    private fun stop() {
        running = false
        pending.clear()
        active.toList().forEach { it.finish() }
        log("থামানো হয়েছে। ZIP বানাতে নিচের বাটন চাপুন।")
    }

    private fun pump() {
        while (running && active.size < parallel && pending.isNotEmpty()) {
            val w = Worker(pending.removeFirst())
            active.add(w)
            w.begin()
        }
        if (running && pending.isEmpty() && active.isEmpty()) {
            running = false
            log("সব টুল শেষ।")
            makeZip()
        }
    }

    private fun extOf(mime: String): String = when {
        mime.contains("png") -> "png"
        mime.contains("webp") -> "webp"
        mime.contains("gif") -> "gif"
        else -> "jpg"
    }

    private val JS = """
(function(){
 if(window.__aih)return; window.__aih=1;
 var P=__PROMPT__, seen={}, clicked=0, t0=Date.now(), lastClick=Date.now(), warned=0;
 function docs(){var a=[document];var fs=document.querySelectorAll('iframe');for(var i=0;i<fs.length;i++){try{if(fs[i].contentDocument)a.push(fs[i].contentDocument)}catch(e){}}return a;}
 function vis(e){var r=e.getBoundingClientRect();return r.width>0&&r.height>0;}
 function findPrompt(){
  var ds=docs(),first=null,txt=null;
  for(var d=0;d<ds.length;d++){
   var els=ds[d].querySelectorAll('textarea,input[type=text],input:not([type])');
   for(var i=0;i<els.length;i++){var e=els[i]; if(e.readOnly||e.disabled||!vis(e))continue;
    var s=((e.id||'')+' '+(e.placeholder||'')+' '+(e.name||'')).toLowerCase();
    if(/negative|seed|search|width|height|count|number|size/.test(s))continue;
    if(/prompt|describe|imagine|desc/.test(s))return e;
    if(e.tagName=='TEXTAREA'&&!first)first=e;
    if(e.tagName!='TEXTAREA'&&!txt)txt=e;
   }
  }
  return first||txt;
 }
 function setVal(e,v){
  var w=e.ownerDocument.defaultView;
  var proto=(e.tagName=='TEXTAREA'?w.HTMLTextAreaElement:w.HTMLInputElement).prototype;
  Object.getOwnPropertyDescriptor(proto,'value').set.call(e,v);
  e.dispatchEvent(new w.Event('input',{bubbles:true}));
  e.dispatchEvent(new w.Event('change',{bubbles:true}));
 }
 function findBtn(){
  var ds=docs(),c=[];
  for(var d=0;d<ds.length;d++){
   var bs=ds[d].querySelectorAll('button,input[type=button],input[type=submit],[role=button]');
   for(var i=0;i<bs.length;i++){var b=bs[i]; if(!vis(b)||b.disabled)continue;
    var t=((b.innerText||b.value||b.textContent||'')+' '+(b.id||'')).trim().toLowerCase();
    if(/negative|clear|reset|random|setting|download|gallery|share|copy|stop|cancel|dice/.test(t))continue;
    if(/generat|create|imagine|draw|make|paint|render|submit|run|start/.test(t))return b;
    c.push(b);
   }
  }
  return c.length?c[0]:null;
 }
 function collect(){
  var ds=docs();
  for(var d=0;d<ds.length;d++){var ims=ds[d].images;
   for(var i=0;i<ims.length;i++){var im=ims[i],s=im.currentSrc||im.src;
    if(!s||seen[s]||!im.complete||im.naturalWidth<256||im.naturalHeight<256)continue;
    if(/\.svg(\?|$)/i.test(s))continue;
    seen[s]=1; window.__aihGot=1;
    (function(s){
     if(s.indexOf('blob:')==0||s.indexOf('data:')==0){
      fetch(s).then(function(r){return r.blob()}).then(function(b){var fr=new FileReader();fr.onload=function(){AIH.img(fr.result)};fr.readAsDataURL(b);}).catch(function(e){AIH.note('blob fetch fail')});
     } else AIH.img(s);
    })(s);
   }
  }
 }
 setInterval(function(){
  var p=findPrompt();
  if(p&&!window.__aihSet){setVal(p,P);window.__aihSet=1;p.focus();}
  if(window.__aihSet&&clicked==0){
   var b=findBtn();
   if(b){b.click();clicked=1;lastClick=Date.now();AIH.note('generate চাপা হয়েছে');}
   else if(p){var w=p.ownerDocument.defaultView;p.dispatchEvent(new w.KeyboardEvent('keydown',{key:'Enter',keyCode:13,which:13,bubbles:true}));clicked=1;lastClick=Date.now();AIH.note('Enter চাপা হয়েছে');}
  }
  if(clicked==1&&!window.__aihGot&&Date.now()-lastClick>45000){var b2=findBtn();if(b2)b2.click();clicked=2;}
  if(!p&&!warned&&Date.now()-t0>25000){warned=1;AIH.note('প্রম্পট বক্স পাইনি');}
  collect();
 },1500);
})();
"""

    inner class Worker(val slug: String) {
        val dir = File(root, slug).apply { mkdirs() }
        val wv = WebView(this@MainActivity)
        var stage = 0
        var count = 0
        var closed = false
        var waiting = false
        val t0 = SystemClock.elapsedRealtime()
        @Volatile var lastNew = t0

        @SuppressLint("SetJavaScriptEnabled")
        fun begin() {
            holder.addView(wv, FrameLayout.LayoutParams(480, 480))
            wv.settings.javaScriptEnabled = true
            wv.settings.domStorageEnabled = true
            wv.settings.mediaPlaybackRequiresUserGesture = false
            wv.addJavascriptInterface(Bridge(), "AIH")
            wv.webViewClient = object : WebViewClient() {
                override fun onPageFinished(v: WebView, url: String) {
                    if (closed || waiting) return
                    waiting = true
                    ui.postDelayed({ afterLoad() }, 3000)
                }
            }
            wv.loadUrl("https://perchance.org/$slug")
            ui.postDelayed({ tick() }, 2000)
        }

        fun afterLoad() {
            waiting = false
            if (closed) return
            if (stage == 0) {
                wv.evaluateJavascript("(function(){var f=document.querySelector('iframe[src*=\"perchance.org\"]');return f?f.src:''})()") { r ->
                    val u = (r ?: "").trim('"').replace("\\/", "/")
                    if (!closed) {
                        if (u.startsWith("http")) { stage = 1; wv.loadUrl(u) } else { stage = 2; inject() }
                    }
                }
            } else if (stage == 1) {
                stage = 2; inject()
            }
        }

        fun inject() {
            wv.evaluateJavascript(JS.replace("__PROMPT__", JSONObject.quote(prompt)), null)
        }

        fun tick() {
            if (closed) return
            val now = SystemClock.elapsedRealtime()
            val enough = maxImgs > 0 && count >= maxImgs
            val stalled = stage == 2 && ((count > 0 && now - lastNew > 35_000) || (count == 0 && now - t0 > 120_000))
            val hard = now - t0 > 300_000
            if (enough || stalled || hard) finish() else ui.postDelayed({ tick() }, 2000)
        }

        fun finish() {
            if (closed) return
            closed = true
            try { wv.stopLoading(); holder.removeView(wv); wv.destroy() } catch (e: Exception) { }
            active.remove(this)
            finished++
            report.append("$slug\t$count\n")
            log("[$finished/$total] $slug → $count ছবি")
            pump()
        }

        inner class Bridge {
            @JavascriptInterface
            fun img(src: String) {
                Thread {
                    try {
                        if (closed || (maxImgs > 0 && count >= maxImgs)) return@Thread
                        val bytes: ByteArray
                        val ext: String
                        if (src.startsWith("data:")) {
                            ext = extOf(src.substringAfter("data:").substringBefore(";"))
                            bytes = Base64.decode(src.substringAfter(","), Base64.DEFAULT)
                        } else {
                            val c = URL(src).openConnection()
                            c.connectTimeout = 15000; c.readTimeout = 30000
                            ext = extOf(c.contentType ?: "")
                            bytes = c.getInputStream().readBytes()
                        }
                        synchronized(this@Worker) {
                            if (maxImgs > 0 && count >= maxImgs) return@Thread
                            count++
                            File(dir, "%03d.%s".format(count, ext)).writeBytes(bytes)
                            lastNew = SystemClock.elapsedRealtime()
                        }
                    } catch (e: Exception) {
                        ui.post { log("  $slug: সেভ ব্যর্থ (${e.message})") }
                    }
                }.start()
            }

            @JavascriptInterface
            fun note(s: String) { ui.post { log("  $slug: $s") } }
        }
    }

    private fun makeZip() {
        val r = root ?: return
        log("ZIP বানানো হচ্ছে…")
        Thread {
            try {
                File(r, "report.txt").writeText(report.toString())
                val name = "PerchanceAll_" + System.currentTimeMillis() + ".zip"
                val out: OutputStream
                val where: String
                if (Build.VERSION.SDK_INT >= 29) {
                    val cv = ContentValues().apply {
                        put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                        put(MediaStore.MediaColumns.MIME_TYPE, "application/zip")
                        put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                    }
                    val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)!!
                    out = contentResolver.openOutputStream(uri)!!
                    where = "Downloads/$name"
                } else {
                    val f = File(getExternalFilesDir(null), name)
                    out = FileOutputStream(f)
                    where = f.absolutePath
                }
                ZipOutputStream(BufferedOutputStream(out)).use { z ->
                    z.setLevel(0)
                    r.walkTopDown().filter { it.isFile }.forEach { f ->
                        z.putNextEntry(ZipEntry(f.relativeTo(r).path))
                        f.inputStream().use { it.copyTo(z) }
                        z.closeEntry()
                    }
                }
                ui.post { log("ZIP তৈরি: $where") }
            } catch (e: Exception) {
                ui.post { log("ZIP ব্যর্থ: ${e.message}") }
            }
        }.start()
    }
}
